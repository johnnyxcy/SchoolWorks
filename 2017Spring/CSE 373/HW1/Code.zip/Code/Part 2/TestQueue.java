
public interface TestQueue {
	public void enqueue(String toInput);
	public String dequeue();
}
