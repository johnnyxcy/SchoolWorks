
public class ListQueue {
	private class Node{
		//TODO Implement Linked List Node
	}
	
	//Class variables here, if necessary
	
	
	public ListQueue(){
		//TODO Implement constructor
	}
	
	public void enqueue(String toInput) {
		// TODO Implement enqueue
	}
	
	public String dequeue(){
		// TODO Implement dequeue
		return null;
	}
	
	public String front(){
		// TODO Implement front
		return null;
	}

}
