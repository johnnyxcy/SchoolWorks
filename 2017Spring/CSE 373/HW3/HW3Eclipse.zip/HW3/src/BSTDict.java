public class BSTDict implements Dictionary {
	private class BSTNode{
		//TODO implement Node class
	}
	
	BSTNode root;
	
	public void insert(int key, String value) {
		// TODO implement insert
		
	}

	public String find(int key) {
		// TODO implement find
		return null;
	}

	public boolean delete(int key) {
		// TODO implement delete
		return false;
	}

}
