public class UADict implements Dictionary {

	public void insert(int key, String value) {
		// TODO implement insert
		
	}

	public String find(int key) {
		// TODO implement find
		return null;
	}

	public boolean delete(int key) {
		// TODO implement delete
		return false;
	}

}
