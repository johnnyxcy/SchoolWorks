NAME = 'Tic-Tac-Toe'

INITIAL_STATE = \
              [[[' ',' ',' '],
                [' ',' ',' '],
                [' ',' ',' ']], "X"]

K = 3
