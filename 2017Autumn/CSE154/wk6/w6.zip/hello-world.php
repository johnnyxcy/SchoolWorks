<?php
  echo "<h1>I Love Web Programming\n";
  
  echo "<h2>I Love CSE 154</h2>";

#do a for loop to compute the squares
for ($i = 0; $i < 10; $i++) {
    print "$i cube is " . $i * $i * $i. "<br>\n";
}
      
?>