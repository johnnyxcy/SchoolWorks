"use strict";
(function(){
    function $(id) {
        return document.getElementById(id);
    }
    
    window.onload = function() {
        $("dropdown").onchange = dropdownChange;
    }    

    function dropdownChange() {
        let val = $("dropdown").value;
        if (val == "English") {
            $("English").style.display = "block";
            $("Chinese").style.display = "none";
            $("Japanese").style.display = "none";
        } else if (val == "Chinese") {
            $("English").style.display = "none";
            $("Chinese").style.display = "block";
            $("Japanese").style.display = "none";
        } else if (val == "Japanese") {
            $("English").style.display = "none";
            $("Chinese").style.display = "none";
            $("Japanese").style.display = "block";
        }
    }
})();